/**
 *  Exercise
 */

// Question 1 - comprison
/**
 * initialise the variable number to the value of 14
 * console log to check if number is greater than 14
 * write a single line comment as to what will be out putted.
 */
var number = 14;
console.log(number > 14); // false


// Question 2 - comprison
/**
 * initialise the variable number to the value of 21
 * console log to check if number is strictly equal to 20
 * write a single line comment as to what will be out putted.
 */
var number = 21;
console.log(number === 20); // false

// Question 3 - comprison
/**
 * initialise the variable number to the value of 40
 * console log to check if number is less than 45
 * write a single line comment as to what will be out putted.
 */
var number = 40;
console.log(number < 45); // true

// Question 4 - logical ||
/**
 * Initialise the variable x to the value of 15
 * initialise the variable y to the value of 10
 * console log and check if 
 * x is greater than 10 
 * OR
 * y is less than or equal to 10
 * write a single line comment as to what will be displayed
 */
var x = 15;
var y = 10;
console.log(x > 10 || y <= 10); // true

// Question 5 - logical &&
/**
 * Initialise the variable a to the value of 21
 * initialise the variable b to the value of 15
 * console log and check if 
 * a is greater than 20 
 * AND
 * b is less than or equal to 15
 * write a single line comment as to what will be displayed
 */
var a = 21;
var b = 15;
console.log(a > 20 && b <= 15); // true


// Question 6 - logical && and !
/**
 * Initialise the variable e to the value of 40
 * initialise the variable f to the value of 34
 * console log and check if 
 * e is greater than 40 
 * &&
 * f is less than or equal to 35
 * Add a not operator somewhere to make the output true
 * write a single line comment as to what will be displayed
 */
var e = 40;
var f = 34;
console.log(!(e > 40) && f <= 35); // true


// Question 7 - if/else
/**
 * Initialise the variable school to the value of BCIT
 * Use if/else statements to do the following checking
 * check if SFU
 * else if check UBC
 * else if check BCIT
 * else 
 */
var school = "BCIT";
if(school == "SFU") {
    console.log("First");
} else if(school == "UBC") {
    console.log("Second");
} else if(school == "BCIT") {
    console.log("Third");
} else {
    console.log("Nothing");
}

// Question 8 - if/else


// Question 9 - if/else


// Question 10 - write your own question + answer - logical ||


// Question 11 - write your own question + answer - comparison


// Question 12 - write your own question + answer if/else with comparison


// Question 13 - write your own question + answer - if/else with logical ||


// Question 14 - write your own question + answer - if/else with logical &&


// Question 15 - write your own question + answer - if/else with average, backticks and logical &&